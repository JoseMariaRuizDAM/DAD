﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo
{
    /**
     * 
     */
    class UserEntry
    {
        public static readonly String TABLE = "users";
        public static readonly String ID = "id_staff";
        public static readonly String CONTRASENA = "password";
        public static readonly String ROLE = "role";
    }
}
