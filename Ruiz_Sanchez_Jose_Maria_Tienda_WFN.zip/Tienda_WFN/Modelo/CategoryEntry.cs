﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo
{
    public class CategoryEntry
    {
        public static readonly String TABLE = "categories";
        public static readonly String ID = "id_category";
        public static readonly String DESCRIPCION = "description";
    }
}
