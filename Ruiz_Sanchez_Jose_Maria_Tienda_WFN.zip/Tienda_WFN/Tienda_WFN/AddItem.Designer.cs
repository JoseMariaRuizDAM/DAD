﻿
namespace Tienda_WFN
{
    partial class AddItem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddItem));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.quantity_add_box = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.id_label = new System.Windows.Forms.Label();
            this.informacion_label = new System.Windows.Forms.Label();
            this.name_label = new System.Windows.Forms.Label();
            this.add_basquet_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(122, 127);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(315, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name";
            // 
            // quantity_add_box
            // 
            this.quantity_add_box.Location = new System.Drawing.Point(214, 184);
            this.quantity_add_box.Name = "quantity_add_box";
            this.quantity_add_box.Size = new System.Drawing.Size(100, 26);
            this.quantity_add_box.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(122, 184);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Quantity";
            // 
            // id_label
            // 
            this.id_label.AutoSize = true;
            this.id_label.Location = new System.Drawing.Point(210, 127);
            this.id_label.Name = "id_label";
            this.id_label.Size = new System.Drawing.Size(0, 20);
            this.id_label.TabIndex = 8;
            this.id_label.Click += new System.EventHandler(this.id_label_Click);
            // 
            // informacion_label
            // 
            this.informacion_label.AutoSize = true;
            this.informacion_label.Location = new System.Drawing.Point(122, 75);
            this.informacion_label.Name = "informacion_label";
            this.informacion_label.Size = new System.Drawing.Size(93, 20);
            this.informacion_label.TabIndex = 9;
            this.informacion_label.Text = "Informacion";
            // 
            // name_label
            // 
            this.name_label.AutoSize = true;
            this.name_label.Location = new System.Drawing.Point(395, 127);
            this.name_label.Name = "name_label";
            this.name_label.Size = new System.Drawing.Size(0, 20);
            this.name_label.TabIndex = 10;
            // 
            // add_basquet_btn
            // 
            this.add_basquet_btn.Location = new System.Drawing.Point(126, 235);
            this.add_basquet_btn.Name = "add_basquet_btn";
            this.add_basquet_btn.Size = new System.Drawing.Size(240, 45);
            this.add_basquet_btn.TabIndex = 11;
            this.add_basquet_btn.Text = "Add_Basquet";
            this.add_basquet_btn.UseVisualStyleBackColor = true;
            this.add_basquet_btn.Click += new System.EventHandler(this.add_basquet_btn_Click);
            // 
            // AddItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(636, 450);
            this.Controls.Add(this.add_basquet_btn);
            this.Controls.Add(this.name_label);
            this.Controls.Add(this.informacion_label);
            this.Controls.Add(this.id_label);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.quantity_add_box);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AddItem";
            this.Text = "AddItem";
            this.Load += new System.EventHandler(this.AddItem_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox quantity_add_box;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label id_label;
        private System.Windows.Forms.Label informacion_label;
        private System.Windows.Forms.Label name_label;
        private System.Windows.Forms.Button add_basquet_btn;
    }
}