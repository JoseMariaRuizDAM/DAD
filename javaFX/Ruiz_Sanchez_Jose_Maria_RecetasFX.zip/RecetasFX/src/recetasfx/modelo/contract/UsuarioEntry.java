/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recetasfx.modelo.contract;

/**
 *
 * @author Jose
 */
public class UsuarioEntry {
    public static final String TABLE_NAME = "users";
    public static final String USER = "nick";
    public static final String PASSWORD = "password";
    public static final String ROLE = "role";
}
