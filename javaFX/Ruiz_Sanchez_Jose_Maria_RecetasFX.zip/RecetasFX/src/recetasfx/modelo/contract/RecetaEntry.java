/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recetasfx.modelo.contract;

/**
 *
 * @author Jose
 */
public class RecetaEntry {
    
    public static final String TABLE_NAME = "recetacomida";
    public static final String TITULO = "Titulo";
    public static final String AUTOR = "Autor";
    public static final String TIPO = "Tipo";
    public static final String INGREDIENTES = "Ingrediente";
    public static final String PASOS = "Pasos";
    public static final String NUMERO_COMENSALES = "NumeroComensales";
    public static final String TIEMPO = "Tiempo";
    public static final String CALORIAS = "Calorias";
    public static final String IMAGEN = "Imagen";
}
